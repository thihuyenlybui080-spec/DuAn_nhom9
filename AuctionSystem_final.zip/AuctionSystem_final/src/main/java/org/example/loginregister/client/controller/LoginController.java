package org.example.loginregister.client.controller;

import javafx.animation.PauseTransition;
import javafx.application.Platform;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;
import javafx.util.Duration;
import org.example.loginregister.client.service.SceneManager;
import org.example.loginregister.server.database.DatabaseConfig;
import org.example.loginregister.server.dao.LoginHistoryDAO;

import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;

import static org.example.loginregister.client.controller.MainController.LOGIN_FXML;
import static org.example.loginregister.client.controller.MainController.LOGIN_TITLE;

public class LoginController implements Initializable {
    @FXML
    private Button loginButton;
    @FXML
    private Button cancelButton;
    @FXML
    private Label messageLabel;
    @FXML
    private TextField usernameTF;
    @FXML
    private TextField passwordTF;
    @FXML
    private Button btnRegister;
    @FXML
    private StackPane rootStackPane;

    private final String REGISTER_FXML = "register.fxml";
    private final String REGISTER_TITLE = "Register";

    private final SceneManager sceneManager = new SceneManager(getClass());

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle){
        URL test = getClass().getResource("/org/example/loginregister/login.fxml");
        Platform.runLater(() -> {
            if(rootStackPane.getScene() != null) {
                Stage stage = (Stage) rootStackPane.getScene().getWindow();
                stage.setFullScreen(true);
            }
        });
    }

    public void onRegister(ActionEvent event){
        sceneManager.switchScene(event, REGISTER_FXML, REGISTER_TITLE);
    }
    public void LoginButtonAction(ActionEvent event){
        messageLabel.setText("You try to login");
        if(usernameTF.getText().isBlank() == false && passwordTF.getText().isBlank() == false){
            validateLogin();
        }
        else {
            messageLabel.setText("Please enter username and password!");
        }
    }
    public void cancelButtonAction(ActionEvent event){
        Stage stage = (Stage) cancelButton.getScene().getWindow();
        stage.close();
    }

    public void validateLogin() {
        String username = usernameTF.getText();
        String password = passwordTF.getText();

        try (Connection conn = DatabaseConfig.getConnection()) {
            String sql = "SELECT id, username, full_name, role FROM users WHERE username = ? AND password = ?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                int userId = rs.getInt("id");
                String fullName = rs.getString("full_name");
                String role = rs.getString("role");

                saveLoginHistory(userId, username, "SUCCESS");
                messageLabel.setText("Login successful! Welcome, " + fullName);

                PauseTransition pause = new PauseTransition(Duration.seconds(1));
                pause.setOnFinished(e -> {
                    Stage stage = (Stage) rootStackPane.getScene().getWindow();
                    switch (role) {
                        case "ADMIN"  -> sceneManager.switchScene(stage, "admin_dashboard.fxml",  "Admin Dashboard");
                        case "SELLER" -> sceneManager.switchScene(stage, "seller_dashboard.fxml", "Seller Dashboard");
                        default       -> sceneManager.switchScene(stage, "bidder_dashboard.fxml", "Bidder Dashboard");
                    }
                });
                pause.play();

            } else {
                saveLoginHistory(-1, username, "FAILED");
                messageLabel.setText("Incorrect username or password!");
            }

        } catch (Exception e) {
            saveLoginHistory(-1, username, "FAILED");
            messageLabel.setText("Unable to connect to server, please try again!");
        }
    }

    private void saveLoginHistory(int userId, String username, String status) {
        LoginHistoryDAO.saveLoginHistory(userId, username, status);
    }

}
