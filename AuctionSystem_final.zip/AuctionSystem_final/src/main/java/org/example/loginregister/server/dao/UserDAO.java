package org.example.loginregister.server.dao;

import org.example.loginregister.server.database.DatabaseConfig;
import org.example.loginregister.server.model.entity.user.*;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UserDAO {

    /** Lấy toàn bộ danh sách user (Admin + Seller + Bidder). */
    public static List<User> getAllUsers() {
        List<User> list = new ArrayList<>();
        String sql = "SELECT id, username, password, email, full_name, role FROM users";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapUser(rs));
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] getAllUsers: " + e.getMessage());
        }
        return list;
    }

    /** Lấy user theo username và password (dùng cho login). */
    public static User getUserByCredentials(String username, String password) {
        String sql = "SELECT id, username, password, email, full_name, role FROM users WHERE username = ? AND password = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.setString(2, password);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapUser(rs);
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] getUserByCredentials: " + e.getMessage());
        }
        return null;
    }

    /** Lấy user theo id. */
    public static User getUserById(int userId) {
        String sql = "SELECT id, username, password, email, full_name, role FROM users WHERE id = ?";
        try (Connection conn = DatabaseConfig.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setInt(1, userId);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapUser(rs);
            }
        } catch (SQLException e) {
            System.err.println("[UserDAO] getUserById: " + e.getMessage());
        }
        return null;
    }

    /** Map một dòng ResultSet → User (Bidder / Seller / Admin). */
    public static User mapUser(ResultSet rs) throws SQLException {
        String id       = String.valueOf(rs.getInt("id"));
        String username = rs.getString("username");
        String password = rs.getString("password");
        String email    = rs.getString("email");
        String fullName = rs.getString("full_name");
        String role     = rs.getString("role");

        User user;
        switch (role) {
            case "SELLER": user = new Seller(username, password, email, fullName); break;
            case "ADMIN":  user = new Admin(username, password, email, fullName);  break;
            default:       user = new Bidder(username, password, email, fullName);
        }
        user.setId(id);
        return user;
    }
}
